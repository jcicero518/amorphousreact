<?php
$context = Timber::get_context();

Timber::render('templates/single.twig', $context);